# =============================================================
#  CRYPTO AGENT — DATA
#  Obtiene precios, indicadores técnicos y Fear & Greed
# =============================================================

import requests
import pandas as pd
from datetime import datetime

COINGECKO_IDS = {
    "BTC/USDT": "bitcoin",
    "ETH/USDT": "ethereum",
    "SOL/USDT": "solana",
}


def get_prices_and_indicators(symbols: list[str]) -> dict:
    """
    Devuelve para cada símbolo:
    - precio actual
    - cambio 24h %
    - RSI (14) aproximado con velas de 1h
    - tendencia (EMA20 vs EMA50)
    """
    results = {}

    for symbol in symbols:
        cg_id = COINGECKO_IDS.get(symbol)
        if not cg_id:
            continue
        try:
            # Precio actual + cambio 24h
            price_url = (
                f"https://api.coingecko.com/api/v3/simple/price"
                f"?ids={cg_id}&vs_currencies=usd&include_24hr_change=true"
            )
            pr = requests.get(price_url, timeout=10).json()
            price     = pr[cg_id]["usd"]
            change_24h = pr[cg_id]["usd_24h_change"]

            # Velas históricas (últimas 48h en intervalos de 1h) para indicadores
            ohlc_url = (
                f"https://api.coingecko.com/api/v3/coins/{cg_id}/ohlc"
                f"?vs_currency=usd&days=2"
            )
            ohlc_raw = requests.get(ohlc_url, timeout=10).json()
            closes = pd.Series([c[4] for c in ohlc_raw])

            rsi   = _calc_rsi(closes, period=14)
            ema20 = closes.ewm(span=20).mean().iloc[-1]
            ema50 = closes.ewm(span=50).mean().iloc[-1]
            trend = "ALCISTA" if ema20 > ema50 else "BAJISTA"

            results[symbol] = {
                "price":      round(price, 2),
                "change_24h": round(change_24h, 2),
                "rsi":        round(rsi, 1),
                "ema20":      round(ema20, 2),
                "ema50":      round(ema50, 2),
                "trend":      trend,
            }
        except Exception as e:
            results[symbol] = {"error": str(e)}

    return results


def get_fear_and_greed() -> dict:
    """Retorna el Fear & Greed Index actual (0-100)."""
    try:
        r = requests.get("https://api.alternative.me/fng/?limit=1", timeout=10)
        d = r.json()["data"][0]
        return {
            "value":       int(d["value"]),
            "label":       d["value_classification"],
            "timestamp":   d["timestamp"],
        }
    except Exception as e:
        return {"value": 50, "label": "Neutral", "error": str(e)}


def _calc_rsi(closes: pd.Series, period: int = 14) -> float:
    delta  = closes.diff()
    gain   = delta.clip(lower=0).rolling(period).mean()
    loss   = (-delta.clip(upper=0)).rolling(period).mean()
    rs     = gain / loss.replace(0, 1e-10)
    rsi    = 100 - (100 / (1 + rs))
    return float(rsi.iloc[-1])


def format_market_context(market_data: dict, fng: dict) -> str:
    """Formatea los datos en texto para enviar a Claude."""
    lines = [
        f"=== CONTEXTO DE MERCADO — {datetime.now().strftime('%Y-%m-%d %H:%M')} ===",
        f"Fear & Greed Index: {fng['value']}/100 ({fng['label']})",
        "",
    ]
    for symbol, d in market_data.items():
        if "error" in d:
            lines.append(f"{symbol}: ERROR — {d['error']}")
            continue
        lines += [
            f"--- {symbol} ---",
            f"  Precio:      ${d['price']:,.2f}",
            f"  Cambio 24h:  {d['change_24h']:+.2f}%",
            f"  RSI (14):    {d['rsi']}",
            f"  EMA20/50:    {d['ema20']} / {d['ema50']}  →  Tendencia {d['trend']}",
            "",
        ]
    return "\n".join(lines)
