# =============================================================
#  CRYPTO AGENT — TELEGRAM ALERTS
#  Envía mensajes y alertas al bot configurado
# =============================================================

import requests
from datetime import datetime
from config import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID


BASE_URL = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"


def send(text: str, silent: bool = False) -> bool:
    """Envía un mensaje de texto al chat configurado."""
    try:
        r = requests.post(
            f"{BASE_URL}/sendMessage",
            json={
                "chat_id":              TELEGRAM_CHAT_ID,
                "text":                 text,
                "parse_mode":           "HTML",
                "disable_notification": silent,
            },
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[Telegram ERROR] {e}")
        return False


def send_startup() -> None:
    send(
        "🤖 <b>Crypto Agent iniciado</b>\n"
        f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        "📡 Monitoreando BTC · ETH · SOL\n"
        "🔄 Ciclo cada 15 minutos\n"
        "────────────────────"
    )


def send_signal(signal: dict, market_data: dict) -> None:
    """Formatea y envía una señal de trading."""
    sym = signal.get("symbol", "?")
    direction = signal.get("direction", "?")
    conviction = signal.get("conviction", 0)
    actionable = signal.get("actionable", False)

    price_now = ""
    if sym in market_data and "price" in market_data[sym]:
        price_now = f"${market_data[sym]['price']:,.2f}"

    dir_emoji = {"LONG": "📈", "SHORT": "📉", "NEUTRAL": "➡️"}.get(direction, "❓")
    action_tag = "⚡ <b>SEÑAL ACCIONABLE</b>" if actionable else "👁 <b>SEÑAL NEUTRAL</b>"

    msg = (
        f"{action_tag}\n"
        f"────────────────────\n"
        f"{dir_emoji} <b>{sym}</b>  →  <b>{direction}</b>\n"
        f"💡 Convicción: {conviction}/10\n"
        f"💰 Precio actual: {price_now}\n"
        f"🎯 Entrada:      {signal.get('entry', 'N/A')}\n"
        f"🛑 Stop-loss:    {signal.get('stop_loss', 'N/A')}\n"
        f"✅ Take-profit:  {signal.get('take_profit', 'N/A')}\n"
        f"⚖️ Ratio R/B:    {signal.get('ratio', 'N/A')}\n"
        f"📝 Tesis: {signal.get('thesis', 'N/A')}\n"
        f"────────────────────\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )
    send(msg)


def send_cycle_summary(signals: list[dict], fng: dict, tokens_used: int) -> None:
    """Resumen al final de cada ciclo de análisis."""
    actionable = [s for s in signals if s.get("actionable")]
    neutral    = [s for s in signals if not s.get("actionable")]

    lines = [
        "📊 <b>Resumen del ciclo</b>",
        f"🧠 Fear & Greed: {fng['value']}/100 ({fng['label']})",
        f"⚡ Señales accionables: {len(actionable)}",
        f"➡️ Neutrales: {len(neutral)}",
        f"🔤 Tokens Claude: {tokens_used}",
        f"⏰ {datetime.now().strftime('%H:%M:%S')}",
    ]
    send("\n".join(lines), silent=True)


def send_error(context: str, error: str) -> None:
    send(
        f"⚠️ <b>Error en el agente</b>\n"
        f"📍 Contexto: {context}\n"
        f"❌ Error: {error[:200]}"
    )


def send_daily_limit_hit(loss_usd: float) -> None:
    send(
        f"🚨 <b>LÍMITE DIARIO ALCANZADO</b>\n"
        f"💸 Pérdida del día: ${loss_usd:.2f}\n"
        f"🛑 El agente se detiene hasta mañana.\n"
        f"📋 Revisá el log antes de reiniciar."
    )
