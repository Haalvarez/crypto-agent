# =============================================================
#  CRYPTO AGENT — MAIN
#  Loop principal: datos → cerebro → alertas
#  Correr con: python main.py
# =============================================================

import time
import logging
from datetime import datetime

import config
import data as market_data_module
import brain
import telegram_alerts as tg

# ── Logging ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("agent.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)

# ── Estado del agente ─────────────────────────────────────────
state = {
    "daily_loss_usd":  0.0,
    "halted":          False,
    "cycles_run":      0,
    "last_reset_date": datetime.now().date(),
}


def reset_daily_state_if_needed() -> None:
    today = datetime.now().date()
    if today != state["last_reset_date"]:
        log.info("Nuevo día — reseteando pérdida diaria.")
        state["daily_loss_usd"]  = 0.0
        state["halted"]          = False
        state["last_reset_date"] = today


def run_cycle() -> None:
    """Un ciclo completo: datos → análisis → alertas."""
    cycle_num = state["cycles_run"] + 1
    log.info(f"── Ciclo #{cycle_num} iniciando ──")

    # 1. Datos de mercado
    try:
        mkt = market_data_module.get_prices_and_indicators(config.SYMBOLS)
        fng = market_data_module.get_fear_and_greed()
        context_text = market_data_module.format_market_context(mkt, fng)
        log.info("Datos de mercado obtenidos OK")
    except Exception as e:
        log.error(f"Error obteniendo datos: {e}")
        tg.send_error("fetch de datos", str(e))
        return

    # 2. Análisis con Claude
    try:
        result = brain.analyze(context_text)
        signals = result["signals"]
        tokens  = result["input_tokens"] + result["output_tokens"]
        log.info(f"Claude analizó OK — {len(signals)} señales — {tokens} tokens")
    except Exception as e:
        log.error(f"Error en brain.analyze: {e}")
        tg.send_error("análisis Claude", str(e))
        return

    # 3. Enviar señales por Telegram
    for signal in signals:
        tg.send_signal(signal, mkt)
        time.sleep(0.5)   # pausa para no saturar la API de Telegram

    # 4. Resumen del ciclo
    tg.send_cycle_summary(signals, fng, tokens)

    state["cycles_run"] += 1
    log.info(f"── Ciclo #{cycle_num} completado ──\n")


def main() -> None:
    log.info("=== CRYPTO AGENT ARRANCANDO ===")
    tg.send_startup()

    while True:
        reset_daily_state_if_needed()

        if state["halted"]:
            log.warning("Agente detenido por límite diario. Esperando mañana.")
            time.sleep(60 * 60)   # revisa cada hora
            continue

        try:
            run_cycle()
        except KeyboardInterrupt:
            log.info("Agente detenido manualmente.")
            tg.send("🛑 Agente detenido manualmente.")
            break
        except Exception as e:
            log.error(f"Error inesperado en loop: {e}")
            tg.send_error("loop principal", str(e))

        interval_seconds = config.INTERVAL_MINUTES * 60
        log.info(f"Próximo ciclo en {config.INTERVAL_MINUTES} minutos...")
        time.sleep(interval_seconds)


if __name__ == "__main__":
    main()
