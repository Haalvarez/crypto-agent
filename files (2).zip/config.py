# =============================================================
#  CRYPTO AGENT — CONFIG
#  Completá con tus datos reales antes de correr
# =============================================================

# --- Binance Testnet ---
BINANCE_API_KEY    = "TU_BINANCE_TESTNET_API_KEY"
BINANCE_API_SECRET = "TU_BINANCE_TESTNET_API_SECRET"
BINANCE_TESTNET    = True   # ← cambiar a False cuando vayas a real

# --- Anthropic ---
ANTHROPIC_API_KEY  = "TU_ANTHROPIC_API_KEY"   # sk-ant-...

# --- Telegram ---
TELEGRAM_TOKEN   = "TU_TELEGRAM_BOT_TOKEN"    # 123456:ABC...
TELEGRAM_CHAT_ID = "TU_CHAT_ID_NUMERICO"      # ej: 123456789

# --- Pares que el agente monitorea ---
SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]

# --- Reglas de riesgo (hardcoded, el agente no las puede cambiar) ---
MAX_TRADE_USD        = 10     # máximo por operación en USD
STOP_LOSS_PCT        = 0.04   # 4% de stop-loss por trade
MAX_DAILY_LOSS_USD   = 15     # si se pierde esto en el día, el agente se frena
MAX_OPEN_POSITIONS   = 2      # máximo de posiciones abiertas simultáneas
MIN_SIGNAL_CONVICTION = 7     # solo actuar si Claude da convicción >= 7/10

# --- Intervalo de análisis ---
INTERVAL_MINUTES = 15         # cada cuántos minutos corre el ciclo
